/*
 * Created by IntelliJ IDEA.
 * User: sofdem - sophie.demassey{at}emn.fr
 * Date: Jul 30, 2010 - 9:10:40 AM
 */

package nurseScheduling.data;

/**
 * A solution checker for the Nurse Scheduling Problem
 * Given an instance (a NSData object) and a solution planning (the shift assignments: int[nbEmployees][nbPeriods])
 * @author Sophie Demassey
 */
public class NSChecker {

/**
 * the problem instance
 */
private NSData data;

/**
 * the solution planning to be checked
 * shifts[e][t] is the activity value assigned to employee at period t
 */
private int[][] shifts;

/**
 * the exception thrown when a rule is violated
 */
class CheckException extends Exception {
	public CheckException(String message) {
		super(message);
	}
}

/**
 * initialize the solution checker for a given instance
 * @param data the instance
 */
public NSChecker(NSData data)
{
	this.data = data;
}

/**
 * check if the solution shifts is consistent against the data
 * @param shifts the assignment matrix: shifts[e][t] is the activity value assigned to employee at period t
 * @return true iff the solution is consistent against the data
 */
public boolean checkSolution(int[][] shifts)
{
	this.shifts = shifts;

	try {
		this.checkAssignments();
		this.checkPreAssignments();
		this.checkCovers();
		this.checkMonthlyCards();
		this.checkWeeklyCards();
		this.checkMaxWorkSpan();
		this.checkForbiddenPatterns();
	} catch (CheckException e) {
		System.err.println("Solution is not consistant: ");
		e.printStackTrace();
		return false;
	}
	return true;
}

private void checkAssignments() throws CheckException
{
	for (int[] shift : shifts) {
		for (int s : shift) {
			if (!(s >= 0 && s < data.nbActivities())) {
				throw new CheckException("activity assignment failed");
			}
		}
	}
}

private void checkPreAssignments() throws CheckException
{
	for (int[] trip : data.preAssignments()) {
		boolean mandatory = trip[0]>0;
		int e = trip[1];
		int t = trip[2];
		int a = trip[3];
		if (mandatory) {
			if (shifts[e][t] != a) { throw new CheckException("mandatory assignment failed");}
		} else {
			if (shifts[e][t] == a) { throw new CheckException("forbidden assignment failed");}
		}
	}
}

private void checkCovers() throws CheckException
{
	for (int t=0; t<data.nbDays(); t++) {
		int[] cover = new int[data.nbActivities()];
		for (int e=0; e<data.nbEmployees(); e++) {
			cover[shifts[e][t]]++;
		}
		for (int a=0; a<cover.length; a++) {
			if (!(cover[a] >= data.getMinActivityCover(a) && cover[a] <= data.getMaxActivityCover(a))) {
				throw new CheckException("cover failed");
			}
		}
	}
}

private void checkMonthlyCards() throws CheckException
{
	for (int e=0; e<data.nbEmployees(); e++) {
		int[] cover = new int[data.nbActivities()];
		for (int t=0; t<data.nbDays(); t++) {
			cover[shifts[e][t]]++;
		}
		for (int a=0; a<cover.length; a++) {
			if (!(cover[a] >= data.getMinActivityCard(e, a) && cover[a] <= data.getMaxActivityCard(e, a))) {
				throw new CheckException("monthly card failed");
			}
		}
	}
}

private void checkWeeklyCards() throws CheckException
{
	for (int e=0; e<data.nbEmployees(); e++) {
		for (int w=0; w<data.nbWeeks(); w++) {
			int[] cover = new int[data.nbActivities()];
			for (int t=0; t<7; t++) {
				cover[shifts[e][t+7*w]]++;
			}
			for (int a=0; a<cover.length; a++) {
				if (!(cover[a] >= data.getMinWeekActivityCard(e, a) && cover[a] <= data.getMaxWeekActivityCard(e, a))) {
					throw new CheckException("weekly card failed");
				}
			}
		}
	}
}

private void checkMaxWorkSpan() throws CheckException
{
	for (int e=0; e<data.nbEmployees(); e++) {
		int span = data.getMaxWorkSpan(e);
		int l = 0;
		for (int s : shifts[e]) {
			if (!data.isRestValue(s)) {
				l++;
				if (l > span) { throw new CheckException("max work span failed");}
			} else {
				l = 0;
			}
		}
	}
}

private void checkForbiddenPatterns() throws CheckException
{
	for (int[] shift : shifts) {
		for (String pat : data.forbiddenPatterns()) {
			char[] pattern = pat.toCharArray();
			int freq = pattern[0] - '0';
			if (freq >= 7) {
				int i=1;
				for (int s : shift) {
					if (data.isMatchedBy(s, pattern[i])) {
						i++;
						if (i >= pattern.length) {
							throw new CheckException("forbidden pattern " + pat + " failed");
						}
					} else {
						i = 1;
					}
				}
			} else {
				for (int offset=freq; offset+pattern.length-1<data.nbWeeks(); offset+=7) {
					boolean recognized = true;
					for (int i=1, t=offset; recognized && i<pattern.length; i++, t++) {
						 recognized = data.isMatchedBy(shift[t], pattern[i]);
					}
					if (recognized) {
						throw new CheckException("forbidden pattern " + pat + " failed");
					}
				}

			}
		}
	}
}


}
