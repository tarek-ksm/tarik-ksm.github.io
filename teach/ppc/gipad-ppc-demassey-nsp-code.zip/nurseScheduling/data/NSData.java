/*
 * Created by IntelliJ IDEA.
 * User: sofdem - sophie.demassey{at}emn.fr
 * Date: Jul 27, 2010 - 2:09:07 PM
 */

package nurseScheduling.data;

import gnu.trove.TObjectIntHashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data of a Nurse Scheduling Problem instance.
 * The schedule of an employee (nurse) is an assignment from any period (day) to an activity type.
 * The schedule is feasible if it satisfies the sequencing rules defined by the employee contract.
 * The NSProblem is to find a feasible schedule for each employee on a given time horizon
 * such that the cover requirements at any period and for any activity are satisfied.
 *
 * ASSUMPTIONS:
 * - the first day of the planning is the first day of a month (1st) and the first day of a week (MONDAY)
 * - the number of days in the planning is a multiple of 7
 * - the cover requirements are identical over all the periods
 * - the first 'nbFullEmployees' employees have a full-time contract, the others have a part-time contract
 * - full-time and part-time contracts may define different activity cardinality bounds, but they share the same forbidden pattern rules
 * - mandatory and forbidden assignments may be defined per employee
 * - the initials of the work activity names are all different
 * @author Sophie Demassey
 */
public class NSData {

/** symbol representing a rest period (to be used in forbidden patterns) */
public final static char REST_SYMBOL = '-';

/** symbol representing a non-fixed period (to be used in forbidden patterns) */
public final static char ANY_SYMBOL = '*';

/** symbol representing a work period (to be used in forbidden patterns) */
public final static char WORK_SYMBOL = '$';

/** the activity cardinality types that can be constrained (bounded) */
public enum CardType {
	/** total number of occurrences of an activity */
	HORIZON,
	/** number of occurrences of an activity per week */
	WEEK,
	/** number of consecutive work shifts */
	WORK_SPAN
}

/** number of days (periods) in the planning horizon */
private int nbDays;

/** number of employees (nurses) */
private int nbEmployees;

/** number of employees with a full time contract */
private int nbFullTimeEmployees;

/** number of activities (including REST) */
private int nbActivities;

/** table [nbActivities] of the activity symbols (name first character) including '-' (REST) at the last index (nbActivities-1) */
private char[] symbols;

/** inverse map [nbActivities] of the activity symbols to the activity values (index in table 'symbols') */
 private TObjectIntHashMap<Character> symbolValue;

/** map [nbActivities] of the activity names to the activity values */
private TObjectIntHashMap<String> activityValue;

/** index of the lower bound in the bound tables */
static final int LB = 0;
/** index of the upper bound in the bound tables */
static final int UB = 1;

/** table [2][nbActivities] of the activity cover requirement bounds */
private int[][] coverBounds;

/** map [CardType] to the table [2][nbActivities] of the activity cardinality bounds defined by the full time contract */
private Map<CardType, int[][]> fullCards;

/** map [CardType] to the table [2][nbActivities] of the activity cardinality bounds defined by the part time contract */
private Map<CardType, int[][]> partCards;

/** list of patterns - defined as string of activity symbols prefixed by a day index - that must not appear in any employee schedule */
private List<String> forbiddenPatterns;

/** list of regular expressions of activity values translating the forbidden patterns */
//private List<String> forbiddenRegExps;

/** list of mandatory and forbidden assignments */
private List<int[]> preAssignments;

/** list of employee groups that are interchangeable (ex: same contracts, same pre-assignments) */
private List<int[]> symmetricEmployeeGroups;

/** list of employee groups who require a fair distribution of the activities */
private List<int[]> equityEmployeeGroups;


/**
 * the default instance with 8 employees and 3 activities on 1 month (=28 days) and a list of constraints
 * @return the instance
 */
public static NSData makeInstanceNSP1()
{
	NSData data = new NSData(28, 8, 4, new String[]{"DAY","NIGHT"});

	// COVER: 3 DAY and 1 NIGHT shifts a day
	data.coverBounds = new int[][]{{3,1,4},{3,1,4}};

	// COUNTER: exactly 18 work shifts a month of which at most 4 NIGHT
	data.fullCards.put(CardType.HORIZON, new int[][]{{0,0,10},{28,4,10}});
	// COUNTER: between 4 and 5 work shifts a week
	data.fullCards.put(CardType.WEEK, new int[][]{{0,0,2},{7,7,3}});
	// COUNTER: at most 5 consecutive work shifts
	data.fullCards.put(CardType.WORK_SPAN, new int[][]{{0},{5}});

	// COUNTER: at most 10 work shifts a month of which at most 4 NIGHT
	data.partCards.put(CardType.HORIZON, new int[][]{{0,0,18},{28,4,28}});
	// COUNTER: between 2 and 3 work shifts a week
	data.partCards.put(CardType.WEEK, new int[][]{{0,0,4},{7,7,5}});
	// COUNTER: at most 5 consecutive work shifts
	data.partCards.put(CardType.WORK_SPAN, new int[][]{{0},{5}});

	// Pattern: at most 5 consecutive work shifts (redundant)
	data.addForbiddenPattern("$$$$$$");
	// Pattern: complete week-end
	data.addForbiddenPattern("$-", 5);
	data.addForbiddenPattern("-$", 5);
	// Pattern: no night before a free week-end
	data.addForbiddenPattern("N--", 4);
	// Pattern: two rests after a night or a sequence of nights
	data.addForbiddenPattern("ND");
	data.addForbiddenPattern("N-$");
	// Pattern: at most 2 consecutive worked week-ends
	data.addForbiddenPattern("$$*****$$*****$$", 5);

	// mandatory assignment employee 0 period 0 activity 0
	data.preAssignments.add(new int[]{1, 0, 0, 0});
	// mandatory assignment employee 0 period 1 activity 0
	data.preAssignments.add(new int[]{1, 0, 1, 0});
	// mandatory assignments employee 2
	data.preAssignments.add(new int[]{1, 2, 0, 0});
	data.preAssignments.add(new int[]{1, 2, 1, 0});
	// mandatory assignments employee 3
	data.preAssignments.add(new int[]{1, 3, 0, 1});
	data.preAssignments.add(new int[]{1, 3, 1, 1});
	// mandatory assignments employee 4
	data.preAssignments.add(new int[]{1, 4, 0, 0});
	data.preAssignments.add(new int[]{1, 4, 1, 0});

	// employees 0 and 2 are interchangeable (redundant)
	data.symmetricEmployeeGroups.add(new int[]{0,2});
	// employees 5, 6, 7 are interchangeable (redundant)
	data.symmetricEmployeeGroups.add(new int[]{5,6,7});

	// equity between employees with a full-time contract
	data.equityEmployeeGroups.add(new int[]{0,1,2,3});
	// equity between employees with a part-time contract
	data.equityEmployeeGroups.add(new int[]{4,5,6,7});

	return data;
}

/**
 * build an instance without constraints, initialize the activity tables
 * @param nbDays number of days
 * @param nbEmployees number of employees
 * @param nbFullTimeEmployees number of employees with a full-time contract
 * @param workActivities list of work activity names
 */
private NSData(int nbDays, int nbEmployees, int nbFullTimeEmployees, String[] workActivities)
{
	// periods
	assert nbDays % 7 == 0 : "the number of periods must be a multiple of 7";
	this.nbDays = nbDays;

	// employees
	this.nbEmployees = nbEmployees;
	this.nbFullTimeEmployees = nbFullTimeEmployees;
	this.symmetricEmployeeGroups = new ArrayList<int[]>();
	this.equityEmployeeGroups = new ArrayList<int[]>();

	// activities
	this.nbActivities = workActivities.length+1;
	this.symbols = new char[nbActivities];
	this.activityValue = new TObjectIntHashMap<String>(nbActivities);
	this.symbolValue = new TObjectIntHashMap<Character>(nbActivities);
	for (int a=0; a<workActivities.length; a++) {
		activityValue.put(workActivities[a], a);
		char symbol = workActivities[a].charAt(0);
		symbolValue.put(symbol, a);
		symbols[a]=symbol;
	}
	activityValue.put("REST", nbActivities-1);
	symbolValue.put(REST_SYMBOL, nbActivities-1);
	symbols[nbActivities-1]=REST_SYMBOL;

	// rules for FullTime and PartTime contracts
	this.fullCards = new HashMap<CardType, int[][]>();
	this.partCards = new HashMap<CardType, int[][]>();
	this.forbiddenPatterns = new ArrayList<String>();
	this.preAssignments = new ArrayList<int[]>();
}

/**
 * add a sliding pattern to the list of forbidden patterns : the pattern must not appear at any time in an employee schedule
 * @param symbolPattern sequence of activity symbols
 */
private void addForbiddenPattern(String symbolPattern)
{
	forbiddenPatterns.add("9" + symbolPattern);
}

/**
 * add a week pattern to the list of forbidden patterns: the pattern may appear except starting at a specific day of the week
 * @param symbolPattern sequence of activity symbols
 * @param offset first index of the specific day (0 = MONDAY, ..., 6 = SUNDAY)
 */
private void addForbiddenPattern(String symbolPattern, int offset)
{
	forbiddenPatterns.add(offset+symbolPattern);
}

/**
 * get the number of days in the planning horizon
 * @return the number of days
 */
public int nbDays()
{ return nbDays; }

/**
 * get the number of weeks in the planning horizon
 * @return the number of weeks
 */
public int nbWeeks()
{ return nbDays / 7; }

/**
 * get the number of employees
 * @return the number of employees
 */
public int nbEmployees()
{ return nbEmployees; }

/**
 * get the number of employees having a full-time contract
 * @return the number of employees having a full-time contract
 */
public int nbFullTimeEmployees()
{ return nbFullTimeEmployees; }

/**
 * check whether an employee has a full-time contract
 * @param employeeIndex the employee index
 * @return true iff e has a full-time contract
 */
public boolean isFullTimeEmployee(int employeeIndex)
{ return employeeIndex < nbFullTimeEmployees; }

/**
 * get the number of activities (including REST)
 * @return the number of activities
 */
public int nbActivities()
{ return nbActivities; }

/**
 * get the activity value according to the activity name
 * @param activityName the activity name
 * @return the activity value
 */
public int getValue(String activityName)
{ return activityValue.get(activityName); }

/**
 * get the activity value according to the activity symbol
 * @param activitySymbol the activity symbol
 * @return the activity value
 */
public int getValue(char activitySymbol)
{ return symbolValue.get(activitySymbol); }

/**
 * get the activity symbol according to the activity value
 * @param activityVal the activity value
 * @return the activity symbol
 */
public char getSymbol(int activityVal)
{ return this.symbols[activityVal]; }

/**
 * check whether an activity is a rest or a work shift
 * @param activityVal the activity value
 * @return true iff the activity is a REST
 */
public boolean isRestValue(int activityVal)
{ return activityVal == activityValue.get("REST"); }

/**
 * check whether an activity value matches a symbol
 * @param activityVal the activity value to be checked
 * @param symbol the symbol
 * @return true iff the activity matches the symbol
 */
public boolean isMatchedBy(int activityVal, char symbol)
{ return symbol==ANY_SYMBOL || (symbol==WORK_SYMBOL && activityVal != getValue("REST")) || activityVal == getValue(symbol); }

/**
 * get the groups of symmetric employees
 * @return the groups of symmetric employees
 */
public List<int[]> symmetricEmployeeGroups()
{ return symmetricEmployeeGroups; }

/**
 * get the groups of equitable employees
 * @return the groups of equitable employees
 */
public List<int[]> equityEmployeeGroups()
{ return equityEmployeeGroups; }


/**
 * get the list of mandatory/forbidden assignments
 * an assignment is given by a 4-uple of integers (b, employeeIndex, dayIndex, activityValue) where b=1 if mandatory, b=0 if forbidden
 * @return the list of mandatory/forbidden assignments
 */
public List<int[]> preAssignments()
{ return preAssignments; }

/**
 * get the list of forbidden patterns
 * a pattern is defined by a string of activity symbols prefixed by a number = 9 for a sliding pattern or = the first day index (0=MONDAY, ..., 6=SUNDAY) for a weekly pattern
 * @return the list of forbidden patterns
 */
public List<String> forbiddenPatterns()
{ return forbiddenPatterns; }

/**
 * get the minimum cover required for an activity
 * @param activityVal activity value
 * @return the minimum cover
 */
public int getMinActivityCover(int activityVal)
{ return coverBounds[LB][activityVal]; }

/**
 * get the maximum cover required for an activity
 * @param activityVal activity value
 * @return the maximum cover
 */
public int getMaxActivityCover(int activityVal)
{ return coverBounds[UB][activityVal]; }

/**
 * get the total cover over all periods for an activity: only if the cover is fixed (min=max)
 * @param activityVal activity value
 * @return the total cover
 */
public int getTotalCover(int activityVal)
{ assert coverBounds[LB][activityVal] == coverBounds[UB][activityVal]; return coverBounds[LB][activityVal]* nbDays; }

private Map<CardType, int[][]> getCards(int employeeIndex)
{ return isFullTimeEmployee(employeeIndex) ? fullCards : partCards; }

private int getCard(int employeeIndex, int activity, CardType type, int bound)
{ return getCards(employeeIndex).get(type)[bound][activity]; }


/**
 * get the maximum occurrence number of an activity required for an employee over the planning horizon
 * @param employeeIndex the employee index
 * @param activityValue the activity value
 * @return the maximum occurence number
 */
public int getMaxActivityCard(int employeeIndex, int activityValue)
{ return getCard(employeeIndex, activityValue, CardType.HORIZON, UB); }

/**
 * get the minimum occurrence number of an activity required for an employee over the planning horizon
 * @param employeeIndex the employee index
 * @param activityValue the activity value
 * @return the minimum occurence number
 */
public int getMinActivityCard(int employeeIndex, int activityValue)
{ return getCard(employeeIndex, activityValue, CardType.HORIZON, LB); }

/**
 * get the maximum occurrence number of an activity required for an employee over a week
 * @param employeeIndex the employee index
 * @param activityValue the activity value
 * @return the maximum occurence number per week
 */
public int getMaxWeekActivityCard(int employeeIndex, int activityValue)
{ return getCard(employeeIndex, activityValue, CardType.WEEK, UB); }

/**
 * get the minimum occurrence number of an activity required for an employee over a week
 * @param employeeIndex the employee index
 * @param activityValue the activity value
 * @return the minimum occurence number per week
 */
public int getMinWeekActivityCard(int employeeIndex, int activityValue)
{ return getCard(employeeIndex, activityValue, CardType.WEEK, LB); }

/**
 * get the maximum number of consecutive work shifts required for an employee
 * @param employeeIndex the employee index
 * @return the maximum number of consecutive work shifts
 */
public int getMaxWorkSpan(int employeeIndex)
{ return getCard(employeeIndex, 0, CardType.WORK_SPAN, UB); }

/**
 * get the minimum number of consecutive work shifts required for an employee
 * @param employeeIndex the employee index
 * @return the minimum number of consecutive work shifts
 */
public int getMinWorkSpan(int employeeIndex)
{ return getCard(employeeIndex, 0, CardType.WORK_SPAN, LB); }

/**
 * get the maximum number of work shifts required for an employee over the planning horizon
 * @param employeeIndex the employee index
 * @return the maximum number of work shifts
 */
public int getMaxWork(int employeeIndex)
{ return nbDays - getMinActivityCard(employeeIndex, getValue("REST")); }

/**
 * get the minimum number of work shifts required for an employee over the planning horizon
 * @param employeeIndex the employee index
 * @return the minimum number of work shifts
 */
public int getMinWork(int employeeIndex)
{ return nbDays - getMaxActivityCard(employeeIndex, getValue("REST")); }

/**
 * get the maximum number of work shifts required for an employee over a week
 * @param employeeIndex the employee index
 * @return the maximum number of work shifts per week
 */
public int getMaxWorkPerWeek(int employeeIndex)
{ return 7 - getMinWeekActivityCard(employeeIndex, getValue("REST")); }

/**
 * get the minimum number of work shifts required for an employee over a week
 * @param employeeIndex the employee index
 * @return the minimum number of work shifts per week
 */
public int getMinWorkPerWeek(int employeeIndex)
{ return 7 - getMaxWeekActivityCard(employeeIndex, getValue("REST")); }

}
