/*
 * Created by IntelliJ IDEA.
 * User: sofdem - sophie.demassey{at}emn.fr
 * Date: Jul 27, 2010 - 1:45:04 PM
 */

package nurseScheduling;

import choco.cp.solver.CPSolver;
import choco.kernel.common.logging.ChocoLogging;
import choco.kernel.common.logging.Verbosity;

import nurseScheduling.model.NSCPModelConstrained.NSRules;
import nurseScheduling.data.NSChecker;
import nurseScheduling.data.NSData;
import nurseScheduling.model.NSCPModel;
import nurseScheduling.model.NSCPModelConstrained;

/**
 * the Nurse Scheduling Problem main class:
 * manage an NSP instance data (NSData), the Choco model (NSCPModel), and the solution checker (NSChecker)
 * according to a specified solving configuration
 * @author Sophie Demassey
 */
public class NurseScheduling {

/**
 * a model configuration is a list of NSP constraint types to be modeled
 * this allows to quickly test different models for a same instance
 */
public enum ModelConfiguration
{
	/** the basic configuration with sequencing rules modeled as logical constraints */
	BASIC (NSRules.COVER, NSRules.ASSIGN, NSRules.CARD_M, NSRules.CARD_W, NSRules.SEQ_LOGIC),
	/** same as basic but using an alternative model of the cover rules */
	OTHER (NSRules.COVER_FIX, NSRules.ASSIGN, NSRules.CARD_M, NSRules.CARD_W, NSRules.SEQ_LOGIC);

	private NSRules[] rules;
	private ModelConfiguration(NSRules... rules) { this.rules = rules; }
	private NSRules[] getRules() { return rules; }
}

/** the model configuration */
private ModelConfiguration modelConfiguration;

/** the output verbosity level (set to null to get the default Choco verbosity level) */
private Verbosity chocoVerbosity;

/** the solving time limit in milliseconds (set to null to get no time limit) */
private Integer timeLimitInMS;

/**
 * set the configuration default parameters
 */
public NurseScheduling()
{
	modelConfiguration = ModelConfiguration.BASIC;
	chocoVerbosity = Verbosity.SOLUTION;
	timeLimitInMS = 180000;
}

/**
 * build the NSP1 instance data, then build the Choco model and solve it according to the specified configuration,
 * if a solution is found, check it against the data, then print solutions and statistics.
 */
public void testNSP()
{
	NSData data = NSData.makeInstanceNSP1();

	NSCPModel m = new NSCPModelConstrained(data, modelConfiguration.getRules());
	CPSolver s = new CPSolver();
	s.read(m);

	if (chocoVerbosity != null) ChocoLogging.setVerbosity(chocoVerbosity);
	if (timeLimitInMS != null) s.setTimeLimit(timeLimitInMS);

	if (Boolean.TRUE == s.solve()) {
		ChocoLogging.flushLogs();
		System.out.println(m.solutionToString(s));
		NSChecker checker = new NSChecker(data);
		if (checker.checkSolution(m.solutionToArray(s)))
			System.out.println("Solution checked.");
	}
	ChocoLogging.flushLogs();
	String content =
		s.getTimeCount() + " ms,\t " + s.getNodeCount() + " nodes,\t " + s.getBackTrackCount() + " bks,\t "
		+ m.getDescription() + "\n";
	System.out.println(content);
}

public static void main(String[] args)
{
	NurseScheduling schedule = new NurseScheduling();
	schedule.testNSP();
}


}
