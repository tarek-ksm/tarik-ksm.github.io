/*
 * Created by IntelliJ IDEA.
 * User: sofdem - sophie.demassey{at}emn.fr
 * Date: Jul 29, 2010 - 3:32:02 PM
 */

package nurseScheduling.model;

import choco.kernel.common.util.tools.ArrayUtils;
import nurseScheduling.data.NSData;

/**
 * constrained Choco model of the Nurse Scheduling Problem
 * @author Sophie Demassey
 */
public class NSCPModelConstrained extends NSCPModel {

/**
 * the type of NSP rules to be modelled
 */
public enum NSRules
{
	COVER {void makeConstraint(NSCPModelConstrained model) { model.makeCoverGCC(); }},
	COVER_FIX {void makeConstraint(NSCPModelConstrained model) { model.makeCoverGCCFix(); }},
	ASSIGN {void makeConstraint(NSCPModelConstrained model) { model.makeAssignments(); }},
	CARD_M {void makeConstraint(NSCPModelConstrained model) { model.makeMonthlyCards(); }},
	CARD_W {void makeConstraint(NSCPModelConstrained model) { model.makeWeeklyCards(); }},
	SEQ_LOGIC {void makeConstraint(NSCPModelConstrained model) { model.makeSequences(); }};

	/**
	 * build the Choco constraints corresponding to the NSP rule type and add them to the model
	 * @param model the model to surcharge
	 */
	abstract void makeConstraint(NSCPModelConstrained model);
}

/**
 * build a constrained model according to a given configuration
 * @param data the NSP instance data
 * @param options the types of rules to be added to the model
 */
public NSCPModelConstrained(NSData data, NSRules... options)
{
	super(data);
	for (NSRules opt : options) {
		opt.makeConstraint(this);
		description += opt.name() + " ";
	}
}


/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
//
//      LA SUITE EST A IMPLEMENTER: l'ensemble des contraintes du NSP1
//      � chaque type/impl�mentation de contrainte (par exemple, les contraintes de couverture avec une gcc)
//      correspond un �l�ment de NSRules (par ex, COVER) 
//      et l'appel � la m�thode de construction/ajout de la contrainte Choco (par ex, makeCoverGCC())
//
//      Cette construction permet d'ajouter diff�rentes contraintes et de tester plusieurs impl�mentations possibles
//      d'une m�me contrainte (par ex, COVER_FIX pour mod�liser les couvertures par la version de gcc sans variables d'occurrence)
//
//      R�f�rez-vous � NSData pour acc�der aux donn�es du probl�me
//      R�f�rez-vous � la documentation et � la classe Choco pour l'API des contraintes disponibles
//      R�f�rez-vous � la classe ArrayUtils de choco pour la manipulation des tableaux (ex: append, flatten, transpose)
//
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////



//**************************************************
//      COVER Constraints
//**************************************************

/**
 * model the cover rules for all activities for all periods
 * using GCC (with occurrence variables) constraints
 */
public void makeCoverGCC()
{
	System.err.println("COVER: not yet implemented");
}

/**
 * model the cover rules for all activities for all periods
 * using GCC (with occurrence bounds) constraints
 */
public void makeCoverGCCFix()
{
	System.err.println("COVER_FIX: not yet implemented");

}

//**************************************************
//      MANDATORY/FORBIDDEN Assignments
//**************************************************

/**
 * model the assignment rules for all required or forbidden (employee, period, activity) assignments
 * using...
 */
public void makeAssignments()
{
	System.err.println("ASSIGN: not yet implemented");
}

//**************************************************
//      MONTHLY ACTIVITY CARDINALITY Constraints
//**************************************************

/**
 * model the monthly cardinality rules for all activities and for all employees
 * using...
 */
public void makeMonthlyCards()
{
	System.err.println("CARD_M: not yet implemented");
}

//**************************************************
//      WEEKLY ACTIVITY CARDINALITY Constraints
//**************************************************

/**
 * model the weekly cardinality rules for all week for all activities and for all employees
 * using...
 */
public void makeWeeklyCards()
{
	System.err.println("CARD_W: not yet implemented");
}

//**************************************************
//      SEQUENCING Constraints
//**************************************************

/**
 * model the sequencing rules for all employees
 * using...
 */
public void makeSequences()
{
	System.err.println("SEQ_LOGIC: not yet implemented");
}

}
