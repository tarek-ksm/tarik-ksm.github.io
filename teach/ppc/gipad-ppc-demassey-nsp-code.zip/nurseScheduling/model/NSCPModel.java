/*
 * Created by IntelliJ IDEA.
 * User: sofdem - sophie.demassey{at}emn.fr
 * Date: Jul 27, 2010 - 1:53:16 PM
 */

package nurseScheduling.model;

import choco.Choco;
import choco.Options;
import choco.cp.model.CPModel;
import choco.kernel.common.util.tools.ArrayUtils;
import choco.kernel.model.variables.integer.IntegerVariable;
import choco.kernel.solver.Solver;
import nurseScheduling.data.NSData;

/**
 * Choco model basis for the Nurse Scheduling Problem.
 * define the variables and the common utility methods (print, parse, etc.)
 * @see NSCPModelConstrained the derived class where the constraints are defined
 * @author Sophie Demassey
 */
public class NSCPModel extends CPModel {

/** the instance data */
protected NSData data;

/** the table [nbEmployees][nbDays] of assignment variables */
protected IntegerVariable[][] shifts;

/** the table [nbEmployees][nbActivities] of activity counter variables */
protected IntegerVariable[][] occurrences;

/** the table [nbActivities][nbDays] of activity cover variables */
protected IntegerVariable[][] covers;

/** a short description (the list of constraints) of the built model */
protected String description;

/**
 * build a Choco CP Model without constraints
 * @param data the instance data
 */
public NSCPModel(NSData data)
{
	super();
	this.data = data;
	this.makeVariables();
	this.description = "NSCPModel: ";
}

/**
 * build the model variables
 */
private void makeVariables()
{
	this.shifts = Choco.makeIntVarArray("S", data.nbEmployees(), data.nbDays(), 0, data.nbActivities()-1, "cp:enum");

	this.occurrences = new IntegerVariable[data.nbEmployees()][data.nbActivities()];
	for (int e=0; e<data.nbEmployees(); e++) {
		for (int a=0; a< occurrences[e].length; a++) {
			occurrences[e][a] = Choco.makeIntVar("n" + data.getSymbol(a) + e, data.getMinActivityCard(e, a), data.getMaxActivityCard(e, a), "cp:bound", Options.V_NO_DECISION);
		}
	}

	this.covers = new IntegerVariable[data.nbActivities()][];
	for (int a=0; a< covers.length; a++) {
		this.covers[a] = Choco.makeIntVarArray("B", data.nbDays(), data.getMinActivityCover(a), data.getMaxActivityCover(a), "cp:bound", Options.V_NO_DECISION);
	}

	this.addVariables(ArrayUtils.flatten(shifts));
	this.addVariables(ArrayUtils.flatten(occurrences));
}

/**
 * print the current solver solution if exists
 * @param s the CPSolver
 * @return the solution as a pretty print string
 */
public String solutionToString(Solver s)
{
	if (Boolean.TRUE != s.isFeasible()) {
		return null;
	}
	StringBuffer buf = new StringBuffer(100);

	for (int e=0; e<shifts.length; e++) {
		for (IntegerVariable v : shifts[e]) {
			buf.append(data.getSymbol(s.getVar(v).getVal())).append(" ");
		}
		buf.append("% ");
		for (IntegerVariable v : occurrences[e]) {
			buf.append((s.getVar(v) == null) ? ". " : s.getVar(v).getVal() + " ");

		}
		buf.append("\n");
	}
	return buf.toString();
}

/**
 * get the current solver solution as the assignment table if exists
 * @param s the CPSolver
 * @return the current solver solution as the assignment table [nbEmployees][nbDays] if exists, null otherwise
 */
public int[][] solutionToArray(Solver s)
{
	if (Boolean.TRUE != s.isFeasible()) {
		return null;
	}
	int[][] solution = new int[shifts.length][shifts[0].length];
	for (int e=0; e<shifts.length; e++) {
		for (int t=0; t<shifts[e].length; t++) {
			solution[e][t] = s.getVar(shifts[e][t]).getVal();
		}
	}
	return solution;
}

/**
 * get a description of the model configuration
 * @return the description (list of constraints)
 */
public String getDescription()
{
	return description + ".";
}

}